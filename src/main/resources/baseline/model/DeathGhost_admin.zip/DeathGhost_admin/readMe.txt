﻿※※※该模板原始文件格式为php※※※
※※※css样式以less基础结构生成※※※
※※※每个界面以元素样式展示※※※
※※※使用时根据项目实际情况，对其组合或二次追加样式亦或重置※※※
※※※实际项目中可以将文件直接放在模板根目录下，这里您所看到的只是demo样例，仅供参考。※※※
≡≡≡adminTemplate≡≡≡
»css
»demo-pages
»images
»javascript
»public
»upload
»index.php
»login.php
//根目录开始您的项目文件部署...
..............................
AUTHOR:DEATHGHOST |  DEATHGHOST@DEATHGHOST.CN